# BroCaml
Alyssa Hsu ah2279
Shannon Liu sjl356
Jo Raghavan jbr266
Brooke Ye by239

AI Acknowledgement: 
- Used ChatGPT to determine the best library to implement for fetching data
- Used ChatGPT to assist in implementation of fetching data from a URL to a JSON
- Used ChatGPT to debug our parsing function
- Used ChatGPT to confirm proper specifications